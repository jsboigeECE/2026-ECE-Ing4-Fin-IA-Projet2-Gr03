# Slides de présentation

Placez ici votre fichier PDF (ou PPTX) de support de présentation.

Exemples :
- `slides/presentation.pdf`
- `slides/groupe03_presentation.pptx`

Sinon, vous pouvez documenter un lien vers Google Slides / Canva.

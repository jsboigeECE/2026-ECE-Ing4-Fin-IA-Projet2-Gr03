# Groupe 03 – Dynamique Évolutionniste de Stratégies de Trading

## 🎯 Objectif du projet
Explorer l'évolution de stratégies de trading via des modèles d'**evolutionary game theory** (EGT) :
- Simuler une population de stratégies de trading (trend-following, mean-reversion, EMA 20/50, RSI 14, buy-and-hold, noise) sur un marché simplifié.
- Faire évoluer les parts de marché via la **dynamique replicatrice** (replicator dynamics).
- Identifier des **ESS** (Evolutionarily Stable Strategies) et étudier des effets de "crowding" (saturation).

## 📦 Structure du projet
- `src/` : code source (simulation, modèles, analyse)
- `notebooks/` : explorations et visualisations (Jupyter)
- `docs/` : documentation technique, notes et analyse
- `slides/` : support de présentation (PDF/PPTX ou lien)

## 🧰 Installation (Python)
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## ▶️ Usage principal
### 1) Simulation de base
```bash
python src/simulation.py
```
Cela génère :
- une matrice de payoff estimée à partir d'un modèle de marché synthétique
- une dynamique replicatrice (population évolutive)
- un graphe des fréquences de stratégies
- une liste des stratégies pures ESS détectées

### 2) Notebook interactif
```bash
jupyter notebook notebooks/replicator_dynamics.ipynb
```
Utilisez ce notebook pour :
- modifier les paramètres de simulation
- tester des stratégies nouvelles
- analyser la stabilité/ESS

## 🧪 Expérimentations recommandées
### Minimum (validé)
- Population de 2-3 stratégies simples
- Dynamique replicatrice + visualisation de l'évolution

### Bon (objectif)
- Plusieurs stratégies avec paramètres évolutifs
- Paysage de fitness complexe (moteur de génération de marché variable)
- Analyse ESS avec critères d'invasibilité

### Excellent (bonus)
- Coévolution de stratégies (tournois, interactions directes)
- Invasion de mutant et évaluation de la fixation
- Backtest sur données réelles (par ex. `yfinance`) et comparaison avec finance comportementale

## ✅ Checklist de soumission
- [ ] Fork du dépôt créé
- [ ] Sous-répertoire `groupe-03-dynamique-evolutionniste-strategies-trading/` créé
- [ ] Code + notebooks complets dans ce sous-répertoire
- [ ] README détaillé (installation, usage, tests)
- [ ] Documentation technique (ess, analyses, pistes)
- [ ] Slides de présentation disponibles dans `slides/`
- [ ] PR créée et reviewable
- [ ] Tous les membres du groupe identifiés dans la PR

## 🧑‍🤝‍🧑 Membres du groupe (à compléter)
- **Nom 1** - @github1
- **Nom 2** - @github2
- **Nom 3** - @github3
